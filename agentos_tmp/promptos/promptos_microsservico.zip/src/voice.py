def speak(text):
    print(f"[Vox]: {text}")  # Pode integrar com TTS real depois