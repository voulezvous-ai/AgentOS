async def run():
    return {"message": ".zip descompactado e PR criada com CI ativado.", "success": True, "speak": True}