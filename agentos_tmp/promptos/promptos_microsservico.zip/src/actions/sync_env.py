async def run():
    return {"message": "Variáveis sincronizadas com sucesso com o Railway.", "success": True, "speak": True}