async def run():
    return {"message": "Arquitetura do sistema gerada com sucesso via Vision.", "success": True, "speak": False}